DATA_NOT_PROCESSED = "data/raw/color_sensor_data.csv"
DATA_PROCESSED = "data/processed/color_sensor_data_processed.json"